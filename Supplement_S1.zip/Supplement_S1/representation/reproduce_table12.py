"""用相同预测器比较一维与三维历史状态对下一题 L/C/G 的用途。"""

from __future__ import annotations

import csv
import math
import random
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "标量碰撞_作者确认200题_逐题.csv"
OUT = ROOT / "一维与三维历史状态_同规则预测_逐项.csv"
REPORT = ROOT / "一维与三维历史状态_同规则预测_结果说明.md"
DIMS = ("L", "C", "G")
K = 10
ALPHA = 1.0


def avg(xs):
    return sum(xs) / len(xs)


with SOURCE.open(encoding="utf-8-sig", newline="") as f:
    source = [
        {
            "id": r["blind_id"],
            "user": r["user_pseudonym"],
            "t": int(r["history_position"]),
            "s": int(r["score_quarters"]) / 4,
            **{d: int(r[d]) for d in DIMS},
        }
        for r in csv.DictReader(f)
    ]
users = defaultdict(list)
for r in source:
    users[r["user"]].append(r)
for h in users.values():
    h.sort(key=lambda r: r["t"])
    assert [r["t"] for r in h] == [1, 2, 3, 4, 5]


def feature(history, method):
    if method == "scalar":
        return [avg([r["s"] for r in history])]
    return [avg([r[d] for r in history]) for d in DIMS]


def predict(test_user, n, method, d):
    train = [(feature(h[:n], method), h[n][d]) for u, h in users.items() if u != test_user]
    test = feature(users[test_user][:n], method)
    means = [avg([x[j] for x, _ in train]) for j in range(len(test))]
    sds = [
        math.sqrt(avg([(x[j] - means[j]) ** 2 for x, _ in train])) or 1.0
        for j in range(len(test))
    ]
    distances = [
        (sum(((x[j] - test[j]) / sds[j]) ** 2 for j in range(len(test))), i, label)
        for i, (x, label) in enumerate(train)
    ]
    distances.sort()
    neighbors = [label for _, _, label in distances[:K]]
    global_counts = Counter(label for _, label in train)
    neighbor_counts = Counter(neighbors)
    return {
        c: (neighbor_counts[c] + ALPHA * (global_counts[c] + 1) / (len(train) + 3)) / (K + ALPHA)
        for c in (0, 1, 2)
    }


records = []
for user, history in sorted(users.items()):
    for n in range(1, 5):
        target = history[n]
        for d in DIMS:
            for method in ("scalar", "dimensions"):
                p = predict(user, n, method, d)
                truth = target[d]
                records.append(
                    {
                        "user": user,
                        "target_id": target["id"],
                        "history_length": n,
                        "dimension": d,
                        "method": method,
                        "truth": truth,
                        "p0": p[0],
                        "p1": p[1],
                        "p2": p[2],
                        "nll": -math.log(p[truth]),
                        "brier": sum((p[c] - int(c == truth)) ** 2 for c in (0, 1, 2)),
                        "correct": int(max(p, key=p.get) == truth),
                    }
                )

with OUT.open("w", encoding="utf-8-sig", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=list(records[0]))
    writer.writeheader()
    writer.writerows(records)


def metrics(rs):
    return (avg([r["nll"] for r in rs]), avg([r["brier"] for r in rs]), avg([r["correct"] for r in rs]))


paired = defaultdict(list)
lookup = {(r["user"], r["target_id"], r["dimension"], r["method"]): r for r in records}
for user, history in users.items():
    for target in history[1:]:
        for d in DIMS:
            a = lookup[(user, target["id"], d, "scalar")]
            b = lookup[(user, target["id"], d, "dimensions")]
            paired[user].append(a["nll"] - b["nll"])
per_user = {u: avg(vals) for u, vals in paired.items()}
user_ids = sorted(users)
rng = random.Random(20261116)
boot = sorted(avg([per_user[rng.choice(user_ids)] for _ in user_ids]) for _ in range(5000))
delta = avg(list(per_user.values()))

lines = [
    "# 一维与三维历史状态：同规则下一题特征预测",
    "",
    "作者确认的 40 位用户各有 5 道按时间排序的题。以每人前 1–4 题分别形成历史状态，预测紧接的下一题 L/C/G，得到 160 个目标题位、每法 480 个维度预测。",
    "",
    "一维状态是历史题标量 s 的均值；三维状态是历史题 L、C、G 的三个均值。两边用相同的预测器：对每个目标用户，使用其他 39 人相同历史长度的状态与下一题标签作训练集，按训练集各维标准差缩放距离，选最近 10 人的下一题类别，加入强度 1 的训练集总体先验。只改变状态向量维数，其余数据、邻居数、平滑和顺序验证规则相同；没有调参。",
    "",
    "NLL/Brier 越低越好，准确率越高越好。",
    "",
    "| 目标维度 | 状态 | 平均 NLL | 平均 Brier | 准确率 |",
    "|---|---|---:|---:|---:|",
]
for d in ("全部", *DIMS):
    for method in ("scalar", "dimensions"):
        subset = [r for r in records if r["method"] == method and (d == "全部" or r["dimension"] == d)]
        nll, brier, accuracy = metrics(subset)
        lines.append(f"| {d} | {method} | {nll:.4f} | {brier:.4f} | {accuracy:.1%} |")
lines += [
    "",
    f"按用户配对的平均 NLL 差（标量减三维）为 {delta:.4f}；5000 次用户级 bootstrap 的 95% 区间为 [{boot[124]:.4f}, {boot[4874]:.4f}]。正值表示三维状态 NLL 更低。",
    "",
    "**定位：** 这是一个直接比较一维与三维历史均值的轻量任务，对审稿人提出的‘是否需要分别保留状态’提供实测依据。预测目标仍是下一题 L/C/G，不是答案质量；均值和近邻预测器也不是论文的完整 RABCP 滤波器。",
    "",
    f"来源：`{SOURCE.name}`；逐项输出：`{OUT.name}`；代码：`{Path(__file__).name}`。",
]
REPORT.write_text("\n".join(lines) + "\n", encoding="utf-8")
print("targets", len(records) // 6, "delta", delta, "CI", boot[124], boot[4874])
for method in ("scalar", "dimensions"):
    print(method, metrics([r for r in records if r["method"] == method]))
