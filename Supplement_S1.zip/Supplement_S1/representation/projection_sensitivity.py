"""200 道作者确认题的 L/C/G→五级分数描述性敏感性；不评估真实能力准确率。"""

import csv
import math
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE
LABELS = ROOT / "标量碰撞_作者确认200题_逐题.csv"
MAP = LABELS
OUT = HERE / "projection_sensitivity_results.csv"


def read(path):
    with path.open(encoding="utf-8-sig", newline="") as file:
        return list(csv.DictReader(file))


def score(row, a, b):
    # 归一化保留 1—5 的两端；a=1.5、b=0.25 时等于原文公式。
    return 1 + 4 * (a * int(row["G"]) + b * (int(row["L"]) + int(row["C"]))) / (2 * a + 4 * b)


def profile(rows, a, b):
    p = [0.2] * 5
    observations = []
    for row in rows:
        s = score(row, a, b)
        q = [math.exp(-((k - s) ** 2) / (2 * 0.8**2)) for k in range(1, 6)]
        z = sum(q)
        observations.append([v / z for v in q])
        recent = observations[-5:]
        n = len(recent)
        smooth = [sum(2 * (j + 1) / (n * (n + 1)) * item[k] for j, item in enumerate(recent)) for k in range(5)]
        unnormalized = [p[k] * smooth[k] for k in range(5)]
        total = sum(unnormalized)
        p = [v / total for v in unnormalized]
    return sum((k + 1) * p[k] for k in range(5))


def main():
    labels = {row["blind_id"]: row for row in read(LABELS)}
    histories = defaultdict(list)
    for mapping in read(MAP):
        row = labels[mapping["blind_id"]]
        histories[mapping["user_pseudonym"]].append((int(mapping["history_position"]), row))
    histories = {user: [row for _, row in sorted(items)] for user, items in histories.items()}
    assert len(labels) == 200 and len(histories) == 40 and all(len(rows) == 5 for rows in histories.values())
    base_scores = {key: score(row, 1.5, 0.25) for key, row in labels.items()}
    base_profiles = {key: profile(rows, 1.5, 0.25) for key, rows in histories.items()}
    output = []
    for a, b in [(1.2, 0.25), (1.8, 0.25), (1.5, 0.2), (1.5, 0.3)]:
        score_diffs = [abs(score(row, a, b) - base_scores[key]) for key, row in labels.items()]
        profile_diffs = [abs(profile(rows, a, b) - base_profiles[user]) for user, rows in histories.items()]
        rounded_changed = sum(round(profile(rows, a, b)) != round(base_profiles[user]) for user, rows in histories.items())
        output.append({
            "a_G": a, "b_LC": b, "n_questions": len(labels), "n_users": len(histories),
            "mean_abs_question_score_change": round(sum(score_diffs) / len(score_diffs), 6),
            "max_abs_question_score_change": round(max(score_diffs), 6),
            "mean_abs_final_profile_change": round(sum(profile_diffs) / len(profile_diffs), 6),
            "max_abs_final_profile_change": round(max(profile_diffs), 6),
            "nearest_integer_level_changed_users": rounded_changed,
        })
    with OUT.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=list(output[0]))
        writer.writeheader()
        writer.writerows(output)
    for row in output:
        print(row)


if __name__ == "__main__":
    main()
