"""Offline checks for the two answer comparisons; uses only the Python standard library."""
import csv
import hashlib
from collections import Counter
from pathlib import Path
from statistics import mean

ROOT = Path(__file__).resolve().parent


def load_rows(path):
    with (ROOT / path).open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def depth_instruction(probabilities):
    if sum(probabilities[:2]) >= 0.75:
        return "guided"
    if sum(probabilities[2:]) >= 0.75:
        return "compact"
    return "standard"


def main():
    for row in load_rows("manifest.csv"):
        data = (ROOT / row["path"]).read_bytes()
        assert hashlib.sha256(data).hexdigest() == row["sha256"], row["path"]
    cases = load_rows("tables/table13_cases.csv")
    assert len({r["case_id"] for r in cases}) == len(cases) == 40
    assert sum(int(r["selected_posts"]) for r in cases) == 54
    assert all(int(r["F"]) < int(r["B"]) for r in cases)
    assert all((int(r["selected_posts"]) == 0) == (r["observation"] == "no excerpt selected") for r in cases)
    with_excerpt = [row for row in cases if int(row["selected_posts"])]
    outcomes = {"Clear improvement", "Similar explanation"}
    for row in cases:
        outcome = row["author_review_outcome"]
        if int(row["selected_posts"]):
            assert outcome in outcomes, row["case_id"]
        else:
            assert outcome == "Not in Table 10 (no excerpt selected)", row["case_id"]
    groups = {outcome: [row for row in with_excerpt if row["author_review_outcome"] == outcome]
              for outcome in outcomes}
    groups["All targets with excerpts"] = with_excerpt
    summary = load_rows("tables/answer_summary.csv")
    assert len(summary) == len(groups)
    assert {row["reported_outcome"] for row in summary} == set(groups)
    for row in summary:
        group = groups[row["reported_outcome"]]
        archived_group = row["archived_input_group"]
        archived_ids = {item["case_id"] for item in with_excerpt
                        if archived_group == "all targets with excerpts" or item["observation"] == archived_group}
        assert {item["case_id"] for item in group} == archived_ids, row["reported_outcome"]
        saving = mean(100 * (1 - int(item["F"]) / int(item["B"])) for item in group)
        assert len(group) == int(row["questions"])
        assert f"{100 * len(group) / len(with_excerpt):.1f}" == row["share_of_selected_percent"]
        assert f"{saving:.1f}" == row["mean_input_saving_percent"]
        print(f'{row["reported_outcome"]}: {len(group)} cases, {saving:.1f}% mean input saving')
    overall = mean(100 * (1 - int(row["F"]) / int(row["B"])) for row in cases)
    assert f"{overall:.1f}" == "65.0"
    print(f"All targets: {len(cases)} cases, {overall:.1f}% mean input saving")
    followup = load_rows("followup/cases.csv")
    calls = load_rows("followup/generation.csv")
    assert len(calls) == 54
    assert len({r["case_id"] for r in followup}) == len(followup) == 27
    assert {r["case_id"] for r in followup} <= {r["case_id"] for r in cases}
    observed = Counter((r["case_id"], r["condition"]) for r in calls)
    for row in followup:
        case = row["case_id"]
        probabilities = [float(row[f"p{i}"]) for i in range(1, 6)]
        assert abs(sum(probabilities) - 1) < 0.000001
        assert depth_instruction(probabilities) == row["mode"]
        for group in ("E3", "F3"):
            stem = f"{case}_{group}.txt"
            assert observed[case, group] == 1
            assert (ROOT / "followup" / "answers" / stem).stat().st_size > 0
        base = (ROOT / "followup" / "prompts" / f"{case}_E3.txt").read_text(encoding="utf-8").strip()
        full = (ROOT / "followup" / "prompts" / f"{case}_F3.txt").read_text(encoding="utf-8")
        assert base == full.split("RABCP is an uncertain Dreyfus-stage estimate")[0].strip()
        assert "Prespecified default depth: " + row["mode"].title() in full
    print("Follow-up modes:", dict(Counter(r["mode"] for r in followup)))


if __name__ == "__main__":
    main()
