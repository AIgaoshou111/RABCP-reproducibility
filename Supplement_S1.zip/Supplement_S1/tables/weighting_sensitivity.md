# Reliability weighting and flag-quality sensitivity

These two tables supplement Section 6.4. Both experiments use simulated observations.

## Weight construction

The weight-source comparison uses 420 forty-turn sequences. Simulated confidence is 0.90 for regular observations and 0.65–0.75 for the noise categories. Risk penalties are zero for regular observations and 0.35, 0.40, or 0.45 for high, low, or cross-domain noise. The four tested weights are 1, clip(0.35 + 0.65c), clip(1 − r), and clip(0.35 + 0.65c − r), with clipping to [0.05, 1]. The reference using known simulation labels assigns weight 0.35 to injected noise and 1 to other observations. All runs use window length 5, likelihood width 0.8, and no forgetting. Final error is measured at turn 40. MAE uses turns 10–40. Volatility is within-sequence standard deviation averaged over sequences.

| Weighting | Final error | MAE after turn 10 | Average weight | Volatility |
| --- | ---: | ---: | ---: | ---: |
| No weight | 0.007 | 0.033 | 1.000 | 0.140 |
| Confidence only | 0.006 | 0.032 | 0.906 | 0.139 |
| Risk only | 0.005 | 0.026 | 0.908 | 0.133 |
| Confidence and risk | 0.005 | 0.025 | 0.814 | 0.132 |
| Known synthetic noise | 0.004 | 0.022 | 0.847 | 0.127 |

## Flag quality

The flag-quality comparison uses the same 105 mixed-noise sequences for all rows. The generator supplies the true- and false-positive rates. Stochastic settings use 50 flag realizations. Deterministic settings use one.

| Flag quality | Target TPR | Target FPR | MAE after turn 10 | Seed SD |
| --- | ---: | ---: | ---: | ---: |
| Perfect flag | 1.00 | 0.00 | 0.0407 | 0.0000 |
| High quality | 0.90 | 0.05 | 0.0433 | 0.0013 |
| Moderate | 0.80 | 0.10 | 0.0458 | 0.0019 |
| Low recall | 0.60 | 0.10 | 0.0482 | 0.0021 |
| Noisy detector | 0.60 | 0.20 | 0.0512 | 0.0025 |
| Weak detector | 0.40 | 0.20 | 0.0541 | 0.0022 |
| No flags | 0.00 | 0.00 | 0.0521 | 0.0000 |
